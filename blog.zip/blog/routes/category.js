const express = require('express');
const router = express.Router();
const  category=require("../controllers/category");
/* GET users listing. */
//获取文章
router.get('/', category.index);
//添加文章
router.post('/add', category.save);
//更新文章

router.post("/update/:id",category.update)
//删除文章
router.get("/delete/:id",category.del)
module.exports = router;
